<?php
$conn = new PDO('sqlite:db/database.db');
?>